﻿namespace NVGRenderer.Rendering.Shaders
{
    public enum ShaderType
    {

        Fillgrad,
        FillImg,
        Simple,
        Img

    }
}