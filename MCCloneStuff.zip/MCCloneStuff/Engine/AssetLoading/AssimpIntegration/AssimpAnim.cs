﻿namespace Engine.AssetLoading.AssimpIntegration;

public class AssimpAnim
{
    
}