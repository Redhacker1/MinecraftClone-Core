﻿namespace Engine
{
    public abstract class Game
    {
    
        public virtual void Gamestart()
        {
        }
        
        public virtual void GameEnded()
        {
        }
    }
}