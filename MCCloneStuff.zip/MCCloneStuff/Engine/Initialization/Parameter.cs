﻿namespace Engine.Initialization;

public struct Parameter
{
    public string prefix;
    public string variable;
}