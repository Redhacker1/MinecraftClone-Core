﻿namespace Engine.AssetLoading.AssimpIntegration;

public struct MeshMorphAnimKey
{
    public uint[] Values;
    public double[] Weights;
}