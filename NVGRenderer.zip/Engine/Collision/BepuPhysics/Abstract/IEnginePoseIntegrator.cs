﻿using BepuPhysics;

namespace Engine.Collision.BEPUPhysics;

public interface IEnginePoseIntegrator : IPoseIntegratorCallbacks, IBepuIntegration
{
    
}