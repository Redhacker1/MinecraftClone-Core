﻿namespace Engine.Collision.BEPUPhysics.Implementation;

public class BodyData
{
    
}