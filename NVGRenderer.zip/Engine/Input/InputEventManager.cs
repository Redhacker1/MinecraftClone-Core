﻿namespace Engine.Input
{
    public class InputEventManager
    {
        InputHandler _inputHandler;
        public InputEventManager(InputHandler inputHandler)
        {
            
        }
        
        
        //Action<>




    }
}