﻿using System.Numerics;
using Veldrid;

namespace NVGRenderer.Rendering.Draw;

public struct DrawCall
{
    public ResourceSet Set;
    public Pipeline Pipeline;
    public Vector2 Scissor;
    public uint Offset;
    public uint Count;
}