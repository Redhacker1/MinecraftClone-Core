﻿namespace NVGRenderer.Rendering.Shaders
{
    public enum ShaderType
    {

        FillGrad,
        FillImg,
        Simple,
        Img

    }
}