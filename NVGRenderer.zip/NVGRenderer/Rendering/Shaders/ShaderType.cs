﻿namespace NVGRenderer.Rendering.Shaders
{
    internal enum ShaderType
    {

        Fillgrad,
        FillImg,
        Simple,
        Img

    }
}